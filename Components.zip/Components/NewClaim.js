import React, {Component} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  Picker,
  TextInput,
  FlatList,
} from 'react-native';
import {Icon} from 'react-native-elements';
import LinearGradient from 'react-native-linear-gradient';
import {Actions} from 'react-native-router-flux';
import {Colors} from 'react-native/Libraries/NewAppScreen';
import NewClaimBottomSheet from './NewClaimBottomSheet';
import moment from 'moment'; 

class NewClaim extends Component {
  constructor() {
    super();
    this.state = {
      selectedHead: 'Select',
      dcl_amount: 0,
      claim_date:  moment().format("DD-MMM-YYYY"),//Date.now().toString('dd-MM-yyyy'),
      FbpHeadDetails: [
        {
          PayHeadID: '0',
          PayHead: 'Select',
        },
      ],
    };
  }
  componentDidMount() {
    this.fetch_fbp_head();
  }
  fetch_fbp_head() {
    fetch('http://104.211.160.16:89/api/fetch_fbp_claim_heads', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        token:
          'dolB2/eUb7oieUBWAZeazYB4xM1TECH8pS1ohSFFLyt2oan3Di70E1I7AZdpZGKYw5KRYe5Z7yzW9LuN4CEhY3EoOtJvCZs8BqY/nDAVePr3F9Wk6JjMJ0RQMfCXV8qdI/HgzPaN7ezZve0aS+cMsIK1/r7fjX98I3gMeV+zfSRZBJN6DYe3UAEF/QGIkLr3zhs20wLfEC9jS42ZeqNjliLh2spgzOd54TPMYbe1WZM0PIpfU+eFfCFB/QO2T15CB30DaPvpEQNMCpQmxT7xv3XtEspfkNDpt5HnU9cdEec54nMAQK/rYIKRG2/Yqi2TOQm29h8UzDxaLJMhc5jy8+xKEjXKLQWMsihXAAGzp/mIipy0iNzs62s+aRLB5l7ku+KnCOGAYQWrCF97UDg+ezW/j9Ch+95iTJtOip7bbBVCDa6rvRNpi1GyZJ7Te7xdUtBMMc/IxHXIK3ZzbDkedOUNUAhrQOYuPPpKWrjTLz72n3/UPngWMuQXLFQwbvS2wbL/aNFy2xtRTGTHkXSxRLT4lfUFET/is2eN4MU7wgmVrVJ75meNY0lMoZekbYKCOJGI007DnVPBRJcPfHa1tHZuuqcvu30WKyHUHQdIumO7o7cYThaMZHoTXlOyQ25PMUqfd3GTT6TxKLWMLkcK5FWEr+IIwsuUHNYTmGb2Wox5bEKTi+MbXTIzj1nverJFYax6/dViY25EPyluDAVsc1FuTKywlqdYpHkhfne+/BRtRYY7F7ch2yS04Euekb4T4o8N3tlgL+39RfxGIyWmZ4DUjmhCEcTBbSDqf/hoZNeqGfKiADsZCvP1EC3nZAWBDf3rXDidDVqtr/H2mqxUMj9gF8pg1znEZjD2XthK2k8HqZaA6Qmv7cKT0bNuPsnkBTzhBEt5fsUI4fxh1Kc5NAv0KRsTbO0DncO2JDsqjHPVoXs9WXBv8UDsuMtZRInO',
      }),
    })
      .then(responseJson => responseJson.json())
      .then(response => {
        for (const key in response.FbpHeadDetails) {
          const element = response.FbpHeadDetails[key];
          this.state.FbpHeadDetails.push(element);
        }

        this.setState({
          //FbpHeadDetails,
        });
        //console.log(this.state.FbpHeadDetails);
        //this.DisplayValue(response.SavingsDeclarationMaster);
      })
      .catch(error => {
        console.log(error);
      });
  }

  fetch_dcl_amt = (Payhead) => {
    //alert(Payhead);
    fetch('http://104.211.160.16:89/api/fetch_fbp_declaration_amount_details', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        token:
          'dolB2/eUb7oieUBWAZeazYB4xM1TECH8pS1ohSFFLyt2oan3Di70E1I7AZdpZGKYw5KRYe5Z7yzW9LuN4CEhY3EoOtJvCZs8BqY/nDAVePr3F9Wk6JjMJ0RQMfCXV8qdI/HgzPaN7ezZve0aS+cMsIK1/r7fjX98I3gMeV+zfSRZBJN6DYe3UAEF/QGIkLr3zhs20wLfEC9jS42ZeqNjliLh2spgzOd54TPMYbe1WZM0PIpfU+eFfCFB/QO2T15CB30DaPvpEQNMCpQmxT7xv3XtEspfkNDpt5HnU9cdEec54nMAQK/rYIKRG2/Yqi2TOQm29h8UzDxaLJMhc5jy8+xKEjXKLQWMsihXAAGzp/mIipy0iNzs62s+aRLB5l7ku+KnCOGAYQWrCF97UDg+ezW/j9Ch+95iTJtOip7bbBVCDa6rvRNpi1GyZJ7Te7xdUtBMMc/IxHXIK3ZzbDkedOUNUAhrQOYuPPpKWrjTLz72n3/UPngWMuQXLFQwbvS2wbL/aNFy2xtRTGTHkXSxRLT4lfUFET/is2eN4MU7wgmVrVJ75meNY0lMoZekbYKCOJGI007DnVPBRJcPfHa1tHZuuqcvu30WKyHUHQdIumO7o7cYThaMZHoTXlOyQ25PMUqfd3GTT6TxKLWMLkcK5FWEr+IIwsuUHNYTmGb2Wox5bEKTi+MbXTIzj1nverJFYax6/dViY25EPyluDAVsc1FuTKywlqdYpHkhfne+/BRtRYY7F7ch2yS04Euekb4T4o8N3tlgL+39RfxGIyWmZ4DUjmhCEcTBbSDqf/hoZNeqGfKiADsZCvP1EC3nZAWBDf3rXDidDVqtr/H2mqxUMj9gF8pg1znEZjD2XthK2k8HqZaA6Qmv7cKT0bNuPsnkBTzhBEt5fsUI4fxh1Kc5NAv0KRsTbO0DncO2JDsqjHPVoXs9WXBv8UDsuMtZRInO',
        finacial_start_date:"2021-04-01",
        finacial_end_date:"2022-03-01",
        fbpclaimid:Payhead
      }),
    })
      .then(responseJson => responseJson.json())
      .then(response => {
        this.setState({
          dcl_amount:response.DeclarationAmt,
        })
      })
      .catch(error => {
        console.log(error);
      });
  }

  fetch_fbp_workflow_id(){
    fetch('http://104.211.160.16:89/api/fetch_fbp_declaration_amount_details', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        token:
          'dolB2/eUb7oieUBWAZeazYB4xM1TECH8pS1ohSFFLyt2oan3Di70E1I7AZdpZGKYw5KRYe5Z7yzW9LuN4CEhY3EoOtJvCZs8BqY/nDAVePr3F9Wk6JjMJ0RQMfCXV8qdI/HgzPaN7ezZve0aS+cMsIK1/r7fjX98I3gMeV+zfSRZBJN6DYe3UAEF/QGIkLr3zhs20wLfEC9jS42ZeqNjliLh2spgzOd54TPMYbe1WZM0PIpfU+eFfCFB/QO2T15CB30DaPvpEQNMCpQmxT7xv3XtEspfkNDpt5HnU9cdEec54nMAQK/rYIKRG2/Yqi2TOQm29h8UzDxaLJMhc5jy8+xKEjXKLQWMsihXAAGzp/mIipy0iNzs62s+aRLB5l7ku+KnCOGAYQWrCF97UDg+ezW/j9Ch+95iTJtOip7bbBVCDa6rvRNpi1GyZJ7Te7xdUtBMMc/IxHXIK3ZzbDkedOUNUAhrQOYuPPpKWrjTLz72n3/UPngWMuQXLFQwbvS2wbL/aNFy2xtRTGTHkXSxRLT4lfUFET/is2eN4MU7wgmVrVJ75meNY0lMoZekbYKCOJGI007DnVPBRJcPfHa1tHZuuqcvu30WKyHUHQdIumO7o7cYThaMZHoTXlOyQ25PMUqfd3GTT6TxKLWMLkcK5FWEr+IIwsuUHNYTmGb2Wox5bEKTi+MbXTIzj1nverJFYax6/dViY25EPyluDAVsc1FuTKywlqdYpHkhfne+/BRtRYY7F7ch2yS04Euekb4T4o8N3tlgL+39RfxGIyWmZ4DUjmhCEcTBbSDqf/hoZNeqGfKiADsZCvP1EC3nZAWBDf3rXDidDVqtr/H2mqxUMj9gF8pg1znEZjD2XthK2k8HqZaA6Qmv7cKT0bNuPsnkBTzhBEt5fsUI4fxh1Kc5NAv0KRsTbO0DncO2JDsqjHPVoXs9WXBv8UDsuMtZRInO',
        finacial_start_date:"2021-04-01",
        finacial_end_date:"2022-03-01",
        fbpclaimid:Payhead
      }),
    })
      .then(responseJson => responseJson.json())
      .then(response => {
        this.setState({
          dcl_amount:response.DeclarationAmt,
        })
      })
      .catch(error => {
        console.log(error);
      });
  }

  render() {
    return (
      <View style={styles.mainPage}>
        <LinearGradient
          colors={['#6484e3', '#4ac0d1']}
          style={styles.headerLayout}
          useAngle={true}
          angle={45}
          angleCenter={{x: 0.5, y: 0.5}}>
          <View style={styles.headerLayout}></View>
        </LinearGradient>
        <View style={styles.body}>
          <Text style={{color: 'grey', padding: 4}}>Select FBP Head *</Text>
          {
            <Picker
              style={{marginLeft: 4, marginRight: 4}}
              selectedValue={this.state.selectedHead}
              onValueChange={(itemValue, itemIndex) =>
                this.setState(
                  {
                    selectedHead: itemValue.PayHead,
                  },
                  () =>
                    this.fetch_dcl_amt(itemValue)
                )
              }>
              {this.state.FbpHeadDetails.map((item, key) => (
                <Picker.Item
                  label={item.PayHead}
                  value={item.PayHead}
                  key={key}
                />
              ))}
            </Picker>
          }
          <View style={{flexDirection: 'row'}}>
            <Text style={{color: 'grey', padding: 4}}>
              Declaration Amount :
            </Text>
            <Text style={{padding: 4}}>{this.state.dcl_amount}</Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <Text style={{color: 'grey', padding: 4}}>Claim Date :</Text>
            <Text style={{padding: 4}}>{this.state.claim_date}</Text>
          </View>
          <View style={{padding: 8}}>
            <TouchableOpacity
              style={{
                alignSelf: 'center',
                backgroundColor: '#fff',
                borderRadius: 8,
                elevation: 4,
                paddingBottom: 4,
                paddingTop: 4,
                paddingLeft: 8,
                paddingRight: 8,
              }}
              onPress={() => {
                Actions.NewClaimBottomSheet();
              }}>
              <Text>Add Bill</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.approval_card}>
            <LinearGradient
              colors={['#6484e3', '#4ac0d1']}
              style={{
                padding: 4,
                borderTopLeftRadius: 6,
                borderTopRightRadius: 6,
              }}
              useAngle={true}
              angle={45}
              angleCenter={{x: 0.5, y: 0.5}}>
              <Text style={{color: '#fff', paddingLeft: 8, paddingRight: 8}}>
                Bill Information
              </Text>
            </LinearGradient>
            <View>
              {/* <Text style={{padding:4,color:'grey',fontStyle:'italic'}}>No Claim Details Found!</Text> */}
            </View>
          </View>

          <View style={{padding: 8}}>
            <LinearGradient
              colors={['#6484e3', '#4ac0d1']}
              style={{
                alignSelf: 'flex-end',
                backgroundColor: '#fff',
                borderRadius: 16,
                elevation: 4,
                paddingLeft: 8,
                paddingRight: 8,
                paddingTop: 4,
                paddingBottom: 4,
              }}
              useAngle={true}
              angle={45}
              angleCenter={{x: 0.5, y: 0.5}}>
              <TouchableOpacity
                style={{
                  alignSelf: 'flex-end',
                  padding: 4,
                }}>
                <Text
                  style={{
                    color: '#fff',
                  }}>
                  Submit Claim
                </Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  mainPage: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerLayout: {
    flex: 0.8,
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    alignContent: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    color: '#fff',
    fontSize: 16,
    marginTop: -30,
  },
  textCenter: {
    textAlign: 'center',
    alignContent: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 12,
    marginTop: 8,
    marginBottom: 8,
  },
  liteContrast: {
    color: '#ACACAC',
    fontSize: 12,
  },
  container: {
    flex: 1,
    alignContent: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    flex: 5.2,
    /* flexDirection: 'column', */
    justifyContent: 'flex-start',
    backgroundColor: '#fff',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    paddingTop: 12,
    marginTop: -30,
    /* alignContent: 'center',
      alignItems: 'center', */

    /* "linear-gradient(to right, #30496B,#30B8D2)" */
  },
  bodyContent: {
    flex: 1,
    justifyContent: 'flex-start',
    backgroundColor: '#fff',
  },
  row: {
    flexDirection: 'row',
    alignContent: 'center',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    /* "linear-gradient(to right, #30496B,#30B8D2)" */
  },
  cardItem: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 8,
    elevation: 2,
    padding: 10,
    margin: 10,
    alignContent: 'center',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    alignSelf: 'stretch',
  },
  imgIcon: {
    height: 32,
    width: 32,
  },
  footer: {
    flex: 1,
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignContent: 'center',
    alignItems: 'flex-end',
    justifyContent: 'space-around',
  },
  submit_btn: {
    flex: 1,
    backgroundColor: '#6484e3',
    borderRadius: 50,
    elevation: 8,
    height: 32,
    margin: 10,
    flexDirection: 'row',
    color: '#fff',
    alignContent: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  draft_btn: {
    flex: 1,
    backgroundColor: '#fff',
    color: '#6484e3',
    borderRadius: 50,
    elevation: 8,
    height: 32,
    margin: 10,
    flexDirection: 'row',
    alignContent: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  approval_card: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 6,
    marginLeft: 8,
    marginRight: 8,
    marginTop: 4,
    marginBottom: 4,
  },
  smalltext: {
    fontSize: 12,
    paddingLeft: 4,
    paddingRight: 4,
  },
  input: {backgroundColor: 'gainsboro', height: 38, borderRadius: 8},
});
export default NewClaim /* bottomsheet */;
